package in.conceptarchitect.finance;

public enum AccountStatus {
	
	ACTIVE, CLOSED, SUSPENDED

}
