package demo.testing;

public class SimpleMath {

	
	public int plus(int x,int y) {
		return x+y;
	}
	
	public int minus(int x,int y) {
		return x-y;
	}
	
	public int multiply(int x,int y) {
		return x*y;
	}
	
	public int divide(int x,int y) {
		return x/y;
	}
}
