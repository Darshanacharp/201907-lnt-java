package demo.testing;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=50, y=15;
		SimpleMath math=new SimpleMath();
		
		System.out.println(math.plus(x, y));
		System.out.println(math.minus(x, y));
		System.out.println(math.multiply(x, y));
		System.out.println(math.divide(x, y));
		
		
		
	}

}
