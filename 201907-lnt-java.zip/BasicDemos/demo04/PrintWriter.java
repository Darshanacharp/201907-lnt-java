class PrintWriter{

	public static void write(Object message){

		System.out.println(message);	
	}
}