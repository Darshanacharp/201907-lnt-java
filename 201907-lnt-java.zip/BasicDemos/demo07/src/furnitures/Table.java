class Table{

    int getPrice(){return 5000;}

}