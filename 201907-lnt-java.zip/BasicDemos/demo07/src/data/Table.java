class Table{


    void add(int row, int col, int value){
        System.out.println("adding "+value+ " to ("+row+","+col+")");
    }

}