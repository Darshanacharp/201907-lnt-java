class QuickSort{

	void sort(List list){
		System.out.println("sorting :"+list);
	}
}