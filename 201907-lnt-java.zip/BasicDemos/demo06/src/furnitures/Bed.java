class Bed{

	int getPrice(){return 1000;}

}