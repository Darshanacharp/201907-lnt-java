class Chair{

	int getPrice(){return 1000;}

}