class Sofa{

	int getPrice(){return 1000;}

}