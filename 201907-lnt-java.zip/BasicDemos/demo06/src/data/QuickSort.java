class QuickSort{

	int sort(List list){
		System.out.println("sorting :"+list);
	}
}