class Set{

	int add(int value){
		System.out.println("value added to list :"+value);
	}
}