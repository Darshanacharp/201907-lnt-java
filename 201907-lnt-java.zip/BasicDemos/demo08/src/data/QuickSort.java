package data;

public class QuickSort{

	public void sort(List list){
		System.out.println("sorting :"+list);
	}
}