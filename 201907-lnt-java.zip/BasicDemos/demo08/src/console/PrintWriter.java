package console;

public class PrintWriter{

	public  void write(Object message){

		System.out.println(message);	
	}
}