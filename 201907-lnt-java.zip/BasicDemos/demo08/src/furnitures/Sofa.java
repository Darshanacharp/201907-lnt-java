package furnitures;

public class Sofa{

	public int getPrice(){return 1000;}

}