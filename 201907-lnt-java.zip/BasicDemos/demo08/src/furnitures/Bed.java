package furnitures;
public class Bed{

	public int getPrice(){return 1000;}

}