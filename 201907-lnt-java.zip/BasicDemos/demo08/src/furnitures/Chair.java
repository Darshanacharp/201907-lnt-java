package furnitures;

public class Chair{

	public int getPrice(){return 1000;}

}