package in.conceptarchitect.data;
public class Set{

	public void add(int value){
		System.out.println("value added to list :"+value);
	}
}