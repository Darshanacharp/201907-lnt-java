package in.conceptarchitect.data;

public class List{

	public void add(int value){
		System.out.println("value added to list :"+value);
	}
}