package in.conceptarchitect.furnitures;
public class Bed{

	public int getPrice(){return 1000;}

}