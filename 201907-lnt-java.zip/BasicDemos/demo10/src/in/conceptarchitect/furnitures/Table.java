package in.conceptarchitect.furnitures;

public class Table{

    public int getPrice(){return 5000;}

}